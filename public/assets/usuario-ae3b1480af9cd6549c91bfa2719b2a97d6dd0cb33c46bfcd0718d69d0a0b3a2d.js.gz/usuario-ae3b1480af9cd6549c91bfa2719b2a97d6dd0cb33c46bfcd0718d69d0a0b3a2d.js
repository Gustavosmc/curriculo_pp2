$(document).ready(function(){
   //applies default mask pattern
  VMasker(document.querySelector("#usuario_cpf")).maskPattern("999.999.999-99");
  VMasker(document.querySelector("#usuario_telefone")).maskPattern("(99) 99999-9999");            

  //sets keyup's event to check which mask pattern will be used

  
  
   
   
});

 
