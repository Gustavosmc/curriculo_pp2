$( ".curriculo_cargos" ).change(function() {
  alert( "Handler for .change() called." );
});
